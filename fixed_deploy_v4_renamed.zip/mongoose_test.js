console.log('Requiring mongoose...');
const mongoose = require('mongoose');
console.log('Mongoose required successfully');
